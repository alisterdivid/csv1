<?php
	define("DB_TYPE", "mysql");
	define("DB_HOSTNAME", "localhost");
	define("DB_USERNAME", "root");
	define("DB_PASSWORD", "");
	define("DB_DATABASE", "csvupload");
	
	define("HOST_SERVER", $_SERVER['SERVER_NAME']);
?>
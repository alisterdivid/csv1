<?php
	define("DB_TYPE", "mysql");
	define("DB_HOSTNAME", "localhost");
	define("DB_USERNAME", "root");
	define("DB_PASSWORD", "apmsetup");
	define("DB_DATABASE", "egycars");
	
	define("HOST_SERVER", $_SERVER['SERVER_NAME']);
    define("SITE_NAME", "Auto Select");
    define("NO_PROFILE_PHOTO", "img/profile/noPhoto.png");
    define("NO_CAR_PHOTO", "img/car/noPhoto.png");
    define("EC_MAIL_FROM", "autoselectcars.eg@gmail.com");
    define("EC_MAIL_FROM_PWD", "autoselect2014");

    define("FACEBOOK_APP_ID", "1394090444201507");
    define("FACEBOOK_APP_SECRET", "48f13db54bf703e825a8915ce011dac9");
?>
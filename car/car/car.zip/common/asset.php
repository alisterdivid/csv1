<link rel="stylesheet" href="css/bootstrap.min.css">
<link rel="stylesheet" href="css/bootstrap.style.css">
<link rel="stylesheet" href="css/responsive.css">
<link rel="stylesheet" href="font-awesome/css/font-awesome.css">
<link rel='stylesheet' id='google-fonts-css'  href='http://fonts.googleapis.com/css?family=Open+Sans%3A600%7CRoboto+Condensed%3A400%2C700&#038;ver=3.9' type='text/css' media='all' />

<link rel="stylesheet" href="css/style.css">

<link rel="shortcut icon" href="favicon.ico">
    
<script type="text/javascript" src="js/jquery-1.9.1.js"></script>
<script type="text/javascript" src="js/jquery-ui-1.10.3.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/common.js"></script>
<script type="text/javascript" src="js/function.js"></script>
<script type="text/javascript" src="js/logIn.js"></script>
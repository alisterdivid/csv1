        <div class="col-md-3">            
            <ul class="list-group sidebar-nav-v1">
                <li class="list-group-item <?php if( $pageNo == 1 ) echo "active"; ?>"><a href="userMgrList.php">User Management</a></li>
                <li class="list-group-item <?php if( $pageNo == 2 ) echo "active"; ?>"><a href="carMgrList.php">Car Management</a></li>
                <li class="list-group-item <?php if( $pageNo == 3 ) echo "active"; ?>"><a href="manuMgrList.php">Manufacturer &amp; Model Management</a></li>
                <li class="list-group-item <?php if( $pageNo == 4 ) echo "active"; ?>"><a href="bidMgrList.php">Bid Management</a></li>
                <li class="list-group-item <?php if( $pageNo == 5 ) echo "active"; ?>"><a href="saledMgrList.php">Saled Management</a></li>
                <!-- li class="list-group-item <?php if( $pageNo == 6 ) echo "active"; ?>"><a href="commentMgrList.php">Comment Management</a></li -->
            </ul>
        </div>